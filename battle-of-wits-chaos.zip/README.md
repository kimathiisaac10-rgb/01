# Battle of Wits: Chaos Edition (Kim vs Nelly)

A wild, bold, two‑player split‑screen trivia arena you can run locally (double‑click `index.html`) or deploy to Vercel as a static site.

## Features
- Competitive 1v1 on one device (left vs right)
- Categories: General Knowledge, Pop Culture, Logic, Rapid Math, Relationship, Wild Cards, Memory, Geography, "Us Pack"
- Timers, streaks, energy orbs
- Power‑ups (attacks/defense): Steal, Freeze, Scramble, Blur, Block, Reflect, Swap, Double Dare
- Chaos Round per set (Time Warp, Fog of War, Mirror Match, Shadow Trivia)
- Dares (optional) on wrong answers
- Fully offline static build (no backend)

## Quick Start (Local)
1. Download and unzip.
2. Open `index.html` in any modern browser.
3. Enter names ("Kim" and "Nelly") and press Start.

## Deploy to Vercel
1. Create a new Vercel project (Static Site).
2. Drop these files into the repo root.
3. Deploy. (No build step required.)

## Customize Content
- Edit `assets/questions.json` to add your own questions.
  - `type`: "mcq" | "free"
  - `difficulty`: "easy" | "medium" | "hard" | "insane"
  - For MCQ, provide `options` and the exact `answer` string.
- You can create a new category like "Us Pack" for personal trivia.

## Notes
- This version is hot‑seat (same screen). For online play later, add a realtime service (Supabase/Ably/Pusher) and sync game state via WebSocket.